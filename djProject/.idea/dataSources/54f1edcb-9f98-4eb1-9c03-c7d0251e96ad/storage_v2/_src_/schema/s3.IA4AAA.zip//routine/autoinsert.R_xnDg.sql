create procedure autoinsert()
  BEGIN
declare i int default 1;
while(i<500000)do
insert into t1 values(i,'yuan');
set i=i+1;
end while;
END;

